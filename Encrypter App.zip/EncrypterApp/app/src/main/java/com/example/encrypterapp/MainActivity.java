package com.example.encrypterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
   public static Model model;
   public static SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        model = new Model();
    }


    public void updateView(View view){
        Intent secondActivity = new Intent(this, SecondActivity.class);
        //start second activity
        startActivity(secondActivity);
    }

    public void encrypt(View view) {

        EditText input = (EditText)findViewById(R.id.textInput);
        String inputText = input.getText().toString();

        String encrypted = model.encrypt(inputText);
        input.setText(encrypted);
    }

    public void decrypt(View view) {
        EditText input = (EditText)findViewById(R.id.textInput);
        String inputText = input.getText().toString();

        String decrypted = model.decrypt(inputText);
        input.setText(decrypted);
    }


}