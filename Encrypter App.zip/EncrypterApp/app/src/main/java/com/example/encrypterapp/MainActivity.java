package com.example.encrypterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
   public static Model model;
   public static SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg = (RadioGroup)findViewById(R.id.options);
        model = new Model();
    }


    public void updateView(View view){
        Intent secondActivity = new Intent(this, SecondActivity.class);
        //start second activity
        startActivity(secondActivity);
    }

    public void encrypt(View view) {
        EditText input = (EditText)findViewById(R.id.textInput);
        int selectedId=SecondActivity.rg.getCheckedRadioButtonId();
        String encrypted="";
        String inputText = input.getText().toString();

        if (selectedId==R.id.radioButton1){
            encrypted = model.encrypt(inputText);
        }else if(selectedId==R.id.radioButton2){
            DHKey keygen=new DHKey(model.get());

            long key = keygen.getSecKey();
            long prime=keygen.getPrime();
            System.out.print("key: "+key);
            encrypted=model.encryptDiffie(inputText,key,prime);
        }else if(selectedId==R.id.radioButton3){
            int key=model.get();
            String secret_key=String.valueOf(key);
            encrypted= AESTEST.encrypt(inputText, secret_key);
    }
        else if (selectedId==R.id.radioButton4){

    }
        else{
        System.err.print("Invalid radio button id err");
    }

        input.setText(encrypted);
    }

    public void decrypt(View view) {
        EditText input = (EditText)findViewById(R.id.textInput);
        int selectedId=SecondActivity.rg.getCheckedRadioButtonId();

        String inputText = input.getText().toString();
        String decrypted="";

        if (selectedId==R.id.radioButton1) {

            decrypted = model.decrypt(inputText);

        }else if(selectedId==R.id.radioButton2){
            DHKey keygen=new DHKey(model.get());
            long key = keygen.getSecKey();
            long prime=keygen.getPrime();
            System.out.print("key: "+key);
            decrypted=model.decryptDiffie(inputText,key,prime);
        }else if(selectedId==R.id.radioButton3){
            int key=model.get();
            String secret_key=String.valueOf(key);
            decrypted=AESTEST.decrypt(inputText,secret_key);
        }
        else if (selectedId==R.id.radioButton4){

        }
        else{
            System.err.print("Invalid radio button id err");
        }
        input.setText(decrypted);
    }


}