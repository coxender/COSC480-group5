package com.example.encrypterapp;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    Model model = MainActivity.model;
    private static final String PREFERENCE_NAME = "Key";
    public static SharedPreferences preferences;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_activity);
        //create screen for second view
        updateView();
    }

    private void updateView() {
        SharedPreferences preferences = getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        int key = preferences.getInt("KEY",0);

        EditText inputKey = (EditText)findViewById(R.id.textInput);
        inputKey.setText(key+"");
    }

    public void submit(View view){
        EditText inputKey = (EditText)findViewById(R.id.textInput);
        String input = inputKey.getText().toString();
        int key = Integer.parseInt(input);
        model.set(key);

        SharedPreferences preferences = getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("KEY",key);
        editor.apply();

        finish();
    }
}